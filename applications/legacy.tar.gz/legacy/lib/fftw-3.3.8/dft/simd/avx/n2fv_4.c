/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-avx.h"
#include "../common/n2fv_4.c"
