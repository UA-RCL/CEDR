// #include <mex.h>
//#include <math.h>
// #include <matrix.h>
//#include <complex.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *argv[])
{
	size_t n_samples = 256;
	double T = 0.000512;
	double B = 500000;
	double sampling_rate = 1000;
	size_t dft_size = 2 * n_samples-1;
	double *time = malloc(n_samples*sizeof(double));;
	double *received = malloc(2*n_samples*sizeof(double));
	double *dftMatrix = malloc(2* dft_size * dft_size * sizeof(double));
	double *indftMatrix = malloc(2 * dft_size * dft_size * sizeof(double));
	FILE *fp;
	
	fp = fopen("./input/time_input.txt","r");

	for(size_t i=0; i<n_samples; i++) 
	{
		fscanf(fp,	"%lf", &time[i]);
	}	
	fclose(fp);

	fp = fopen("./input/received_input.txt","r");	
	
	for(size_t i=0; i<2*n_samples; i++) 
	{
		fscanf(fp,"%lf", &received[i]);
	}	
	fclose(fp);

	fp = fopen("./input/dftcoe.txt", "r");

	for (size_t i = 0; i<dft_size * dft_size *2; i++)
	{
		fscanf(fp, "%lf", &dftMatrix[i]);
	}
	fclose(fp);
	fp = fopen("./input/indftcoe.txt", "r");
	for (size_t i = 0; i<dft_size * dft_size * 2; i++)
	{
		fscanf(fp, "%lf", &indftMatrix[i]);
	}
	fclose(fp);

	double lag;
	double *corr = malloc( (2*(2*n_samples - 1)) * sizeof(double));
	double* gen_wave = malloc(2 * n_samples * sizeof(double));

	for (size_t i = 0; i < 2 * n_samples; i += 2)
	{
		gen_wave[i] = sin(M_PI * B / T * pow(time[i / 2], 2));
		gen_wave[i + 1] = cos(M_PI * B / T * pow(time[i / 2], 2));
	}
	//Add code for zero-padding, to make sure signals are of same length

	size_t len = 2 * n_samples - 1;

	double* c = malloc(2 * len * sizeof(double));
	double* d = malloc(2 * len * sizeof(double));

	size_t x_count = 0;
	size_t y_count = 0;

	for (size_t i = 0; i < 2 * len; i += 2)
	{
		(i / 2 > n_samples - 1) && ((c[i] = gen_wave[x_count], c[i + 1] = gen_wave[x_count + 1], x_count += 2) || 1) || (c[i] = 0, c[i + 1] = 0);

		(i > n_samples) && ((d[i] = 0, d[i + 1] = 0) || 1) || (d[i] = received[y_count], d[i + 1] = received[y_count + 1], y_count += 2);

	}

	double* X1 = malloc(2 * len * sizeof(double));
	double* X2 = malloc(2 * len * sizeof(double));
	double* corr_freq = malloc(2 * len * sizeof(double));
	int row;
	int column;
	for (size_t i = 0; i < dft_size * dft_size *2; i += 2)
	{
		row = i /512;
		column = i % 512;
		X1[2*row] += dftMatrix[i] * c[column];
		X1[2*row+1] += dftMatrix[i+1] * c[column+1];
	}

	for (size_t i = 0; i < dft_size * dft_size * 2; i += 2)
	{
		row = i / 512;
		column = i % 512;
		X2[2 * row] += dftMatrix[i] * d[column];
		X2[2 * row + 1] += dftMatrix[i + 1] * d[column + 1];
	}

	for (size_t i = 0; i < 2 * len; i += 2)
	{
		corr_freq[i] = (X1[i] * X2[i]) + (X1[i + 1] * X2[i + 1]);
		corr_freq[i + 1] = (X1[i + 1] * X2[i]) - (X1[i] * X2[i + 1]);
	}


	for (size_t i = 0; i < dft_size * dft_size * 2; i += 2)
	{
		row = i / 512;
		column = i % 512;
		corr[2 * row] += indftMatrix[i] * corr_freq[column];
		corr[2 * row + 1] += indftMatrix[i + 1] * corr_freq[column + 1];
	}

	//Code to find maximum
	double max_corr = 0;
	double index = 0;
	for (size_t i = 0; i < 2 * (2 * n_samples - 1); i += 2)
	{
		// Only finding maximum of real part of correlation
		(corr[i] > max_corr) && (max_corr = corr[i], index = i / 2);

	}
	lag = (n_samples - index) / sampling_rate;
	printf("Lag Value is: %lf \n", lag);
}

