#ifndef __PREAMBLE_H__
#define __PREAMBLE_H__


/* function prototypes */

void preamble(comp_t iData[], comp_t oData[], int len);

#endif
