#ifndef __CYCLIC_PREFIX_H__
#define __CYCLIC_PREFIX_H__

/* function prototypes */
#include "baseband_lib.h"

int cyclicPrefix(comp_t iData[], comp_t oData[], int len, int preLen);


#endif
