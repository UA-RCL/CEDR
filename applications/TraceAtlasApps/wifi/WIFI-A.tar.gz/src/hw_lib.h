#ifndef __LIB_H__
#define __LIB_H__

int mmap_init();
unsigned int *memory_map(int paddr, int size);

#endif

