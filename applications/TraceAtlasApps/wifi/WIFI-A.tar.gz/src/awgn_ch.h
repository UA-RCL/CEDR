#ifndef __AWGN_CH_H__
#define __AWGN_CH_H__


/* function prototypes */

double Gaussion(double miu,double sigma);


#endif
