/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: channel_Eq_types.h
 *
 * MATLAB Coder version            : 3.0
 * C/C++ source code generated on  : 24-Oct-2015 18:20:13
 */

#ifndef __CHANNEL_EQ_TYPES_H__
#define __CHANNEL_EQ_TYPES_H__

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for channel_Eq_types.h
 *
 * [EOF]
 */
