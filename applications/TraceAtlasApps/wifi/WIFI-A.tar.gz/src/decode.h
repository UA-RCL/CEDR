#ifndef __DECODE_H__
#define __DECODE_H__


/* function prototypes */


void messagedecoder(unsigned char *buf);


#endif 

