#ifndef __TX_DATA_H__
#define __TX_DATA_H__

int txDataGen(int txOption, unsigned char inbit[], int symNum);

#endif
