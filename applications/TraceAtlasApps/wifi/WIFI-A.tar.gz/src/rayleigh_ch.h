#ifndef __RAYLEIGH_CH_H__
#define __RAYLEIGH_CH_H__


/* function prototypes */

void randr(double *x,int num,double sigma);

#endif
