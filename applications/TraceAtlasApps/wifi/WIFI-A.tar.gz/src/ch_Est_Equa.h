#ifndef __CH_EST_EQUA_H__
#define __CH_EST_EQUA_H__


/* function prototypes */

int Ch_inter_Eqau(int N, int PI, float *RxData, float *Spilot, float *Ypilot,float *EqRxData);


#endif
