#ifndef __INTER_DEINTER_H__
#define __INTER_DEINTER_H__


/* function prototypes */

int interleaver(signed char datain[],int N, unsigned char top1[]);
int deinterleaver(signed char data[], int N, signed char top2[]);

#endif

