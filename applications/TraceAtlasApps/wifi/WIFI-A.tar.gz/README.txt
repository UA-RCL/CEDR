build/ - contains the Makefile and the build results
src/ - contains the source code

to build, go to build/
run make
