#!/bin/sh

ARCH="x86"

if [ "$#" -eq 1 ]; then
  echo "Setting arch flag to $1"
  ARCH="$1"
fi

../../traceExtractCompile.sh \
  --arch ${ARCH} -lm --loop-partition --trace-compression 8 \
  radar_correlator.c
