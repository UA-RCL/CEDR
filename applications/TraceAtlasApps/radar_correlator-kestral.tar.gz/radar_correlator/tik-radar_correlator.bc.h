
// Auto-generated header for the tik representations of output-radar_correlator.ll
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

struct tikStruct0 {
	uint32_t a;
	uint8_t* b;
	uint8_t* c;
	uint8_t* d;
	uint8_t* e;
	uint8_t* f;
	uint8_t* g;
	uint8_t* h;
	uint8_t* i;
	uint8_t* j;
	uint8_t* k;
	uint8_t* l;
	struct tikStruct1* m;
	struct tikStruct0* n;
	uint32_t o;
	uint32_t p;
	uint64_t q;
	uint16_t r;
	uint8_t s;
	uint8_t t[1];
	uint8_t* u;
	uint64_t v;
	uint8_t* w;
	uint8_t* x;
	uint8_t* y;
	uint8_t* z;
	uint64_t aaaa;
	uint32_t bbbb;
	uint8_t cc[20];
};

struct tikStruct1 {
	struct tikStruct1* a;
	struct tikStruct0* b;
	uint32_t c;
};

uint8_t K0(uint8_t arg0, uint64_t* arg1, uint64_t* arg2, struct tikStruct0** arg3, double** arg4);

uint8_t K1(uint8_t arg0, uint64_t* arg1, uint64_t* arg2, struct tikStruct0** arg3, double** arg4);

uint8_t K2(uint8_t arg0, uint64_t* arg1, uint64_t* arg2, struct tikStruct0** arg3, double** arg4);

uint8_t K3(uint8_t arg0, uint64_t* arg1, uint64_t* arg2, uint64_t* arg3, double** arg4, uint64_t* arg5, double** arg6, double** arg7, double** arg8, uint64_t* arg9);

uint8_t K4(uint8_t arg0, uint64_t* arg1, uint64_t* arg2, uint32_t* arg3, uint32_t* arg4, double** arg5, double** arg6, double** arg7);

uint8_t K5(uint8_t arg0, uint64_t* arg1, uint64_t* arg2, uint32_t* arg3, uint32_t* arg4, double** arg5, double** arg6, double** arg7);

uint8_t K6(uint8_t arg0, uint64_t* arg1, uint64_t* arg2, double** arg3, double** arg4, double** arg5);

uint8_t K7(uint8_t arg0, uint64_t* arg1, uint64_t* arg2, uint32_t* arg3, uint32_t* arg4, double** arg5, double** arg6, double** arg7);

uint8_t K8(uint8_t arg0, uint64_t* arg1, uint64_t* arg2, double** arg3, double* arg4);

#ifdef __cplusplus
}
#endif
