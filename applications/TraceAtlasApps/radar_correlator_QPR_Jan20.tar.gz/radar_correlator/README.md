To use:

Edit `radar_correlator.c` to fix the hard coded file paths
Edit `compileAndTrace.sh` to fix the path to TRACEHOME
Run `./compileAndTrace.sh radar_correlator.c`

To make comparisons, `radar_correlator.c` can be compiled with standard GCC and run
